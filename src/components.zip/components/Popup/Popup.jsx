            {/* <div className="p-3 border border-gray-300 rounded-xl">
              <section className="rounded-xl h-[243px] bg-[#23439D] w-[300px] md:w-[338px] bg-no-repeat relative">
                <div className="absolute inset-0 flex flex-col justify-center">
                  <p className="text-center text-white uppercase text-4xl">
                    Thank You!
                  </p>
                  <p className="text-md my-3 text-center text-white/80 font-medium">
                    It is on the way to your mailbox, go back!
                  </p>
                  <div className="flex flex-col gap-y-3 items-center justify-center my-5">
                    <Button
                      text="Go to my page"
                      className="uppercase py-3 px-10 rounded-md text-white font-medium bg-[#435BA9]"
                    />
                  </div>
                </div>
              </section>
            </div>
                            <button onClick={toggleTimerPopup} className="absolute top-0 right-0 p-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button> */}








                
              {/* <div className="p-3 border border-gray-300 rounded-xl mr-8 mt-2">
                <section className="rounded-xl h-[395px] bg-[#23439D] w-[322px] md:w-[350px] bg-no-repeat relative">
                  <div className="absolute inset-0">
                    <div className="mx-6 p-3 !bg-[#435BA9] rounded-md shadow-md mt-5">
                      <p className="text-center my-2 text-white">You have</p>
                      <p className="text-[45px] text-center text-white font-semibold leading-10 tracking-widest uppercase">
                        00 : 30
                      </p>
                      <div className="flex items-center gap-4 justify-center text-white/70 text-[18px] my-3 uppercase">
                        <p>Minutes</p>
                        <p>Seconds</p>
                      </div>
                      <p className="text-center text-white/80 text-[18px] font-medium">
                        {" "}
                        left to sign up to get access!
                      </p>
                    </div>

                    <p className="text-center my-3 text-white/80 text-lg font-medium">
                      Sign up to get access!
                    </p>

                    <div className="flex flex-col gap-y-3 items-center justify-center my-5">
                      <input
                        type="email"
                        name=""
                        placeholder="example@gmail.com"
                        className="py-3 px-5 w-72 rounded-md text-white font-medium bg-[#6173AF] placeholder:text-white/70"
                      />
                      <Button
                        text="Get the Ebook"
                        className="py-1 px-[93px] rounded-xl text-primary font-medium bg-white mt-5"
                      />
                    </div>
                  </div>
                </section>
                </div>
                <button onClick={toggleTimerPopup} className="absolute top-0 right-0 p-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button> */}